<?php
header('Location: ./index.php?m=Admin');

