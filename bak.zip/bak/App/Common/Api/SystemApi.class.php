<?php

namespace Common\Api;
class SystemApi {

	
	
}