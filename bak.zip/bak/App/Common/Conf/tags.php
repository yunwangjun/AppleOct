<?php
return array(
	'app_init'=>array('Common\Behavior\InitHookBehavior'),
    'view_begin'=>array('Common\Behavior\basictemplateBehavior'),
);