<?php
namespace Admin\Controller;
class TagsController extends CommonController {
	

	
}

?>