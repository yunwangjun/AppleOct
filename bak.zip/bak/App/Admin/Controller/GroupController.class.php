<?php
namespace Admin\Controller;
class GroupController extends CommonController {
	

}

?>