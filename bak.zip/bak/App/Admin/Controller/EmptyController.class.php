<?php
namespace Admin\Controller;
class EmptyController extends CommonController{

    protected function getActionName(){
        return CONTROLLER_NAME;
    }


}

?>