<?php
namespace Admin\Controller;
class CommentsController extends CommonController {
	public function _initialize(){
		
		
		parent::_initialize('LocalComment');
		
		
	}

	
}

?>