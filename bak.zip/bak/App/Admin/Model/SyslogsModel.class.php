<?php
namespace Admin\Model;
// 系统日志模型
class SyslogsModel extends CommonModel {
	public $_validate	=	array(
	);

	public $_auto		=	array(
	//		/array('create_time','time',self::MODEL_INSERT,'function'),
	);
}
?>