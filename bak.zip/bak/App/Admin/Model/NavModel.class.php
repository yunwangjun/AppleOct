<?php
namespace Admin\Model;
use Think\Model;

// 配置类型模型
class NavModel extends CommonModel {
    protected $_validate = array(
       
       
    
    	
        );

  

}
?>