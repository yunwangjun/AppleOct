<?php

/**
 * UCenter客户端配置文件
 * 注意：该配置文件请使用常量方式定义
 */

define('UC_APP_ID', 1); //应用ID
define('UC_API_TYPE', 'Model'); //可选值 Model / Service
define('UC_AUTH_KEY', 'z,cWyC(Or~qB=}je`9X*Ia;^>M3Ki+tL0bT-:HuD'); //加密KEY
define('UC_DB_DSN', 'mysql://qdm119567425:AppleoctLC2020@qdm119567425.my3w.com:3306/qdm119567425_db'); // 数据库连接，使用Model方式调用API必须配置此项
define('UC_TABLE_PREFIX', 'jwc_'); // 数据表前缀，使用Model方式调用API必须配置此项
