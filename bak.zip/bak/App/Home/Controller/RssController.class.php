<?php
namespace Home\Controller;
use Org\Util\Rss;

class RssController extends HomeController {
    public function article(){
	
		$Blogs = D('Article');
		$blog = $Blogs->where(array('status'=>1))->getField('id,title,description,create_time,uid');
		
	
		
		$RssConf = array('channelTitle'=>'果拾网',
			             'channelLink'=>'http://www.yunwangjun.cn',
			             'channelDescrīption'=>'果拾网',
			             'copyright'=>'AppleOct');
		$RSS = new Rss($RssConf);
		foreach ($blog as $k => $v) {
			
			$RSS->AddItem($v['title'] ,ZSU('/artc/'.$v['id'],'Index/artc',array('id'=>$v['id'])) ,$v['description'] ,toDate($v['create_time']) ,$v['id'] ,get_username($v['uid']));
		}
		$RSS->SaveToFile("./rss.xml");
		echo $RSS->Show();
	
    }
}