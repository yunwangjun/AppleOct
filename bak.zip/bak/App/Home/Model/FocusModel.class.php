<?php
namespace Home\Model;
use Think\Model;


class FocusModel extends Model {

 protected $_auto = array(
        array('create_time', NOW_TIME, 1),
       
        );

    
   
}
