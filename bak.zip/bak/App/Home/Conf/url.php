<?php 
return array (
  'URL_MODEL' => 1,
  'URL_HTML_SUFFIX' => 'shtml',
  'URL_PATHINFO_DEPR' => '/',
);