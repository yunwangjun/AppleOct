<?php 
return array (
  'DEFAULT_THEME' => 'simple',
);