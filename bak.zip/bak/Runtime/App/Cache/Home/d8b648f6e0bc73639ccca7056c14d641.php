<?php if (!defined('THINK_PATH')) exit(); if($config['type']==1){ ?>
<title><?php echo ($seotitle); ?></title>
<meta name="keyword" content="<?php echo ($seokeyword); ?>">
<meta name="description" content="<?php echo ($seodescription); ?>">
<?php } ?>