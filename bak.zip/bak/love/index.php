<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <title>我们的爱</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <style type="text/css">
        @font-face {
            font-family: digit;
            src: url('digital-7_mono.ttf') format("truetype");
        }
    </style>
    <link href="style/default.css" type="text/css" rel="stylesheet">
    <script type="text/javascript" src="style/jquery.js"></script>
    <script type="text/javascript" src="style/garden.js"></script>
    <script type="text/javascript" src="style/functions.js"></script>
</head>
<body>

<?php
if (!isset($_GET['g']) && !isset($_GET['b'])) {
?>
<form action='#' method='get' style="margin:0 auto;width:520px;">
	<fieldset width="700px" height="700px">
		<legend> 我们的爱 </legend>
		<br />
		男生姓名：<input id="boy" name='b' value=''>
		<br />
		<br />
		女生姓名：<input id="girl" name='g' value=''>
		<br />
					<br />
		<input type='button' name='submit' onclick="javascript:reg();" value='提交'>
	</fieldset>
</form>
<script type="text/javascript">
	function reg(){
		var b = document.getElementById("boy").value;
		var g = document.getElementById("girl").value;
		if (b=='') {
			alert("请填写男生姓名！");
			return ;
		}
		if (g==''){
			alert("请填写女生姓名！");
			return ;
		}
		window.location.href="/love/?b="+b+"&g="+g;
	}
</script>
<?php
} else {
	$girl = isset($_GET['g']) ? $_GET['g'] : 'girlName';
	$boy  = isset($_GET['b']) ? $_GET['b'] : 'boyName';
?>
    <div id="mainDiv">
	<a style="text-decoration:none;font-size:16px;margin-left:16px;" href="http://love.yearnfar.com">填写信息</a>
        <div id="content">
            <div id="code">
                <span class="comments">/**</span><br />
                <span class="space"/><span class="comments">* 我们都是XXX 的屌丝,</span><br />
                <span class="space"/><span class="comments">* 所以我写一些代码来显示我对你的爱.</span><br />
                <span class="space"/><span class="comments">*/</span><br />
                Boy i = <span class="keyword">new</span> Boy(<span class="string">"<?php echo $boy;?>"</span>);<br />
                Girl u = <span class="keyword">new</span> Girl(<span class="string">"<?php echo $girl;?>"</span>);<br />
                <span class="comments">// <?php error_reporting(0); echo date('Y年m月d日'); ?>，我告诉你，我爱你. </span><br />
                i.love(u);<br />
                <span class="comments">// 但是......，你说这是什么意思，我们还是好朋友.</span><br />
                u.sayOtherthing();<br />
                <span class="comments">// 从那以后，我问你的原因。</span><br />
                <span class="keyword">var</span> reason=i.ask(u);<br />
                <span class="comments">// 你说我们没有充分理解对方。</span><br />
                $("body").append(reason);<br />
                <span class="comments">// 你说，这是我们太快成为情人关系。</span><br />
                <span class="comments">// 并采取和我们爱的关怀。</span><br />
                i.takeCareOf(u);<br />
                <span class="comments">// 所以我一直在等待，我有信心，你会的。</span><br />
                <span class="keyword">boolean</span> isAccept = <span class="keyword">false</span>;<br />
                <span class="keyword">while</span> (isAccept) {<br />
                <span class="placeholder"/>i.waitFor(u);<br />
                <span class="placeholder"/><span class="comments">// 我认为这是一个重要的决定</span><br />
                <span class="placeholder"/><span class="comments">// 你应该忘了之前不开心的事。</span><br />
                <span class="placeholder"/>isAccept = u.thinkOver();<br />
                }<br />
                <span class="comments">// 经过一个爱的声音接受，我们将从此过幸福地生活在一起。</span><br />
                u.accept(i);<br />
                i.liveHappilyWith(u);<br />
			
            </div>
            <div id="loveHeart">
                <canvas id="garden"></canvas>
                <div id="words">
                    <div id="messages">
						<center></center>
                        <?php echo $girl;?>，我爱你！520！
                        <div id="elapseClock" style="display:none"></div>
                        <a href='#' id="accept">如果接受我，点击我！</a>
                    </div>
                    <div id="loveu">
                        爱你，直到永远。<br/>
                        <div class="signature">- <?php echo $boy;?></div>
                    </div>
                </div>
            </div>
        </div>
       
    </div>
    <script type="text/javascript">
        var offsetX = $("#loveHeart").width() / 2;
        var offsetY = $("#loveHeart").height() / 2 - 55;
        
        if (!document.createElement('canvas').getContext) {
            var msg = document.createElement("div");
            msg.id = "errorMsg";
            msg.innerHTML = "Your browser doesn't support HTML5!<br/>Recommend use Chrome 14+/IE 9+/Firefox 7+/Safari 4+"; 
            document.body.appendChild(msg);
            $("#code").css("display", "none")
            $("#copyright").css("position", "absolute");
            $("#copyright").css("bottom", "10px");
            document.execCommand("stop");
        } else {
            setTimeout(function () {
                adjustWordsPosition();
                startHeartAnimation();
            }, 10000);
            
            $("#accept").click(function(){
                $(this).hide();
                $("#elapseClock").show();
                var together = new Date();
                timeElapse(together);
                setInterval(function () {
                    timeElapse(together);
                }, 500);
            })
            adjustCodePosition();
            $("#code").typewriter();
        }
    </script>
<?php } ?>

</body>
</html>

